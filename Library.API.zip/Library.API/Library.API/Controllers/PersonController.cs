﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//namespace Library.API.Controllers
//{
//    [Route("api/person")]
//    [ApiVersion("1.0")]
//    public class PersonController : ControllerBase
//    {
//        [HttpGet]
//        public ActionResult<string> Get() => "Result from v1";
//    }
//}
//namespace Library.API.Controllers.V2
//{
//    [Route("api/person")]
//    [ApiVersion("2.0")]
//    public class PersonController : ControllerBase
//    {
//        [HttpGet]
//        public ActionResult<string> Get() => "Result from v2";
//    }
//}
namespace Library.API.Controllers.V1
{
    [ApiVersion("1.0")]
    [Route("api/person")]
    public class StudentController : ControllerBase
    {
        [HttpGet]
        public ActionResult<string> Get() => "Result from v1";
    }
}
//namespace Library.API.Controllers.V2
//{
//    [ApiVersion("2.0")]
//    [Route("api/person")]
//    public class StudentController : ControllerBase
//    {
//        [HttpGet]
//        public ActionResult<string> Get() => "Result from v2";
//    }
//}
