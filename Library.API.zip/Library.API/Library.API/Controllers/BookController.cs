﻿using AutoMapper;
using Library.API.Entities;
using Library.API.FilterAttribute;
using Library.API.Models;
using Library.API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Library.API.Helpers;
using Microsoft.Net.Http.Headers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace Library.API.Controllers
{
    [Route("api/authors/{authorId}/books")]
    [ApiController]
    [ServiceFilter(typeof(CheckAuthorExistFilterAttribute))]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]

    public class BookController : ControllerBase
    {
        public IMemoryCache MemoryCache { get; }
        public IRepositoryWrapper RepositoryWrapper { get; }
        public IMapper Mapper { get; }
        public BookController(IRepositoryWrapper repositoryWrapper, IMapper mapper, IMemoryCache memoryCache)
        {
            RepositoryWrapper = repositoryWrapper;
            Mapper = mapper;
            MemoryCache =memoryCache;
        }

        [HttpGet(Name =nameof(GetBooksAsync))]
        public async Task<ActionResult<IEnumerable<BookDto>>> GetBooksAsync(Guid authorId)
        {
            //var books = await RepositoryWrapper.Book.GetBooksAsync(authorId);
            //var bookDtoList = Mapper.Map<IEnumerable<BookDto>>(books);
            //return bookDtoList.ToList();
            List<BookDto> bookDtoList = new List<BookDto>();
            string key = $"{authorId}_books";
            if (!MemoryCache.TryGetValue(key, out bookDtoList))
            {
                var books = await RepositoryWrapper.Book.GetBooksAsync(authorId);
                bookDtoList = Mapper.Map<IEnumerable<BookDto>>(books).ToList();
                MemoryCache.Set(key, bookDtoList);
            }
            return bookDtoList;
        }
        [HttpGet("{bookId}", Name = nameof(GetBookAsync))]
        public async Task<ActionResult<BookDto>> GetBookAsync(Guid authorId, Guid bookId)
        {
            var book = await RepositoryWrapper.Book.GetBookAsync(authorId, bookId);
            if (book == null)
            {
                return NotFound();
            }
            var bookDto = Mapper.Map<BookDto>(book);
            return bookDto;
        }
        [HttpPost(Name =nameof(AddBookAsync))]
        public async Task<IActionResult> AddBookAsync(Guid authorId, BookForCreationDto bookForCreationDto)
        {
            var book = Mapper.Map<Book>(bookForCreationDto);
            book.AuthorId = authorId;
            RepositoryWrapper.Book.Create(book);
            if (!await RepositoryWrapper.Book.SaveAsync())
            {
                throw new Exception("创建资源Book失败");
            }
            var bookDto = Mapper.Map<BookDto>(book);
            return CreatedAtRoute(nameof(GetBookAsync), new { bookId = bookDto.Id }, bookDto);
        }
        //[HttpPut("{bookId}")]
        //public async Task<IActionResult> UpdateBookAsync(Guid authorId, Guid bookId, BookForUpdateDto updatedBook)
        //{
        //    var book = await RepositoryWrapper.Book.GetBookAsync(authorId, bookId);
        //    if (book == null)
        //    {
        //        return NotFound();
        //    }
        //    Mapper.Map(updatedBook, book, typeof(BookForUpdateDto), typeof(Book));
        //    RepositoryWrapper.Book.Update(book);
        //    if (!await RepositoryWrapper.Book.SaveAsync())
        //    {
        //        throw new Exception("更新资源Book失败");
        //    }
        //    return NoContent();
        //}
        [HttpPut("{bookId}",Name =nameof(UpdateBookAsync))]
        [CheckIfMatchHeaderFilter]
        public async Task<IActionResult> UpdateBookAsync(Guid authorId, Guid bookId, BookForUpdateDto updatedBook)
        {
            var book = await RepositoryWrapper.Book.GetBookAsync(authorId, bookId);
            if (book == null)
            {
                return NotFound();
            }
            var entityHash = HashFactory.GetHash(book);
            if (Request.Headers.TryGetValue(HeaderNames.IfMatch, out var requestETag)
                && requestETag != entityHash)
            {
                return StatusCode(StatusCodes.Status412PreconditionFailed);
            }
            Mapper.Map(updatedBook, book, typeof(BookForUpdateDto), typeof(Book));
            RepositoryWrapper.Book.Update(book);
            if (!await RepositoryWrapper.Book.SaveAsync())
            {
                throw new Exception("更新资源Book失败");
            }
            var entityNewHash = HashFactory.GetHash(book);
            Response.Headers[HeaderNames.ETag] = entityNewHash;
            return NoContent();
        }

        [HttpPatch("{bookId}", Name = nameof(PartiallyUpdateBookAsync))]
        public async Task<IActionResult> PartiallyUpdateBookAsync(Guid authorId, Guid bookId, JsonPatchDocument<BookForUpdateDto> patchDocument)
        {
            var book = await RepositoryWrapper.Book.GetBookAsync(authorId, bookId);
            if (book == null)
            {
                return NotFound();
            }
            var bookUpdateDto = Mapper.Map<BookForUpdateDto>(book);
            patchDocument.ApplyTo(bookUpdateDto, ModelState);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            Mapper.Map(bookUpdateDto, book, typeof(BookForUpdateDto), typeof(Book));
            RepositoryWrapper.Book.Update(book);
            if (!await RepositoryWrapper.Book.SaveAsync())
            {
                throw new Exception("更新资源Book失败");
            }
            return NoContent();
        }










        //public IAuthorRepository AuthorRepository { get; }
        //public IBookRepository BookRepository { get; }

        //public BookController(IBookRepository bookRepository,IAuthorRepository authorRepository)
        //{
        //    AuthorRepository = authorRepository;
        //    BookRepository = bookRepository;
        //}
        //[HttpGet]
        //public ActionResult<List<BookDto>> GetBooks(Guid authorId)
        //{
        //    if(!AuthorRepository.IsAuthorExits(authorId))
        //    {
        //        return NotFound();
        //    }
        //    return BookRepository.GetBooksForAuthor(authorId).ToList();
        //}
        //[HttpGet("{bookId}",Name ="GetBook")]
        //public ActionResult<BookDto> GetBook(Guid authorId,Guid bookId)
        //{
        //    if (!AuthorRepository.IsAuthorExits(authorId))
        //    {
        //        return NotFound();
        //    }
        //    var targetBook = BookRepository.GetBookForAuthor(authorId,bookId);
        //    if (targetBook == null)
        //    {
        //        return NotFound();
        //    }
        //    return targetBook;
        //}
        //[HttpPost]
        //public IActionResult AddBook(Guid authorId,BookForCreationDto bookForCreationDto)
        //{
        //    if (!AuthorRepository.IsAuthorExits(authorId))
        //    {
        //        return NotFound();
        //    }
        //    var newBook = new BookDto
        //    {
        //        Id = Guid.NewGuid(),
        //        Title = bookForCreationDto.Title,
        //        Description = bookForCreationDto.Description,
        //        Pages = bookForCreationDto.Pages,
        //        AuthorId = authorId
        //    };
        //    BookRepository.AddBook(newBook);
        //    return CreatedAtRoute(nameof(GetBook),new { authorId=authorId,bookId=newBook.Id},newBook);

        //}
        //[HttpDelete("{bookID}")]
        //public IActionResult DeleteBook(Guid authorId,Guid bookId)
        //{
        //    if (!AuthorRepository.IsAuthorExits(authorId))
        //    {
        //        return NotFound();
        //    }
        //    var book = BookRepository.GetBookForAuthor(authorId,bookId);
        //    if (book == null)
        //    {
        //        return NotFound();
        //    }
        //    BookRepository.DeleteBook(book);
        //    return NoContent();
        //}
        //[HttpPut("{bookId}")]
        //public IActionResult UpdateBook(Guid authorId, Guid bookId,BookForUpdateDto updatedBook)
        //{
        //    if (!AuthorRepository.IsAuthorExits(authorId))
        //    {
        //        return NotFound();
        //    }
        //    var book = BookRepository.GetBookForAuthor(authorId, bookId);
        //    if (book == null)
        //    {
        //        return NotFound();
        //    }
        //    BookRepository.UpdateBook(authorId, bookId,updatedBook);
        //    return NoContent();
        //}
        //[HttpPatch("{bookId}")]
        //public IActionResult PartiallyUpdateBook(Guid authorId,Guid bookId, [FromBody]JsonPatchDocument<BookForUpdateDto> patchDocument)
        //{
        //    if (!AuthorRepository.IsAuthorExits(authorId))
        //    {
        //        return NotFound();
        //    }
        //    var book = BookRepository.GetBookForAuthor(authorId,bookId);
        //    if (book == null)
        //    {
        //        return NotFound();

        //    }
        //    var bookToPatch = new BookForUpdateDto
        //    {
        //        Title = book.Title,
        //        Description = book.Description,
        //        Pages = book.Pages
        //    };
        //    // patchDocument.ApplyTo(bookToPatch,ModelState);
        //    patchDocument.ApplyTo(bookToPatch,ModelState);
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    BookRepository.UpdateBook(authorId,bookId,bookToPatch);
        //    return NoContent();

        //}


    }
}
