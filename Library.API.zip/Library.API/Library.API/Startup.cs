using Library.API.Entities;
using Library.API.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Library.API.FilterAttribute;
using NLog.Web;
using NLog.Extensions.Logging;
using Library.API.Filter;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System;

namespace Library.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(config =>
            {
                config.Filters.Add<JsonExceptionFilter>();
                config.ReturnHttpNotAcceptable = true;
                config.CacheProfiles.Add("Default",
                new CacheProfile()
                {
                     Duration = 60
                 });
                config.CacheProfiles.Add("Never",
                    new CacheProfile()
                    {
                        Location = ResponseCacheLocation.None,
                        NoStore = true
                    });

                // config.OutputFormatters.Add(new XmlSerializerOutputFormatter());
            }).SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
          //  .AddXmlSerializerFormatters();
            services.AddScoped<IRepositoryWrapper, RepositoryWrapper>();
            services.AddControllers().AddNewtonsoftJson();
            services.AddScoped<CheckAuthorExistFilterAttribute>();
            //services.AddScoped<IAuthorRepository, AuthorMockRepository>();
            //services.AddScoped<IBookRepository, BookMockRepository>();
            services.AddDbContext<LibraryDbContext>(
                option =>
                {
                    option.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
                    // option.

                });
            services.AddResponseCaching(options =>
            {
                options.UseCaseSensitivePaths = true;
                options.MaximumBodySize = 1024;
            });
            services.AddMemoryCache();
            //SqlServer����
            services.AddDistributedSqlServerCache(options =>
            {
                options.ConnectionString = Configuration["DefaultConnection"];
                options.SchemaName = "dbo";
                options.TableName = "TestCache";
            });
            //Redis����
            services.AddStackExchangeRedisCache(options =>
            {
                // �����ַ���
                options.Configuration = "192.168.111.134,password=aW1HAyupRKmiZn3Q";
                // ����ǰ׺
                options.InstanceName = "xoyozo_";
            });
            services.AddApiVersioning(options=> {
                options.AssumeDefaultVersionWhenUnspecified = true;
                options.DefaultApiVersion = new ApiVersion(1,0);
                options.ReportApiVersions=true;
                //options.ApiVersionReader = new QueryStringApiVersionReader();
                // options.ApiVersionReader = new HeaderApiVersionReader("api-version");
                options.ApiVersionReader = new MediaTypeApiVersionReader();
            });
           // services.AddAuthentication(defaultScheme: JwtBearerDefaults.AuthenticationScheme);
            //  services.AddAuthentication(defaultScheme: JwtBearerDefaults.AuthenticationScheme).AddCookie().AddJwtBearer() ;
            var tokenSection = Configuration.GetSection("Security:Token");
            services.AddIdentity<User, Role>().AddEntityFrameworkStores<LibraryDbContext>();
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuer = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = tokenSection["Issuer"],
                    ValidAudience = tokenSection["Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenSection["Key"])),
                    ClockSkew = TimeSpan.Zero
                };
            });

            services.AddAutoMapper(typeof(Startup));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env,IMapper Mapper,ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            //loggerFactory.AddNLog();

            //env.ConfigureNLog("nlog.xml");

            app.UseHttpsRedirection();
            app.UseResponseCaching();
            

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
