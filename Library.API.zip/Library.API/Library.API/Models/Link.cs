﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library.API.Models
{
    public class Link
    {
        public string Href { get; }
        public string Method { get; }
        [JsonProperty("rel")]
        public string Relation { get; }
        public Link(string method,string rel,string href)
        {
            Method = method;
            Href = href;
            Relation = rel;

        }



    }
}
