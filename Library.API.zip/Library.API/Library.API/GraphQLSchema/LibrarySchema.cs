﻿using System;
using System.Collections.Generic;
using System.Text;
using GraphQL.Types;
using GraphQL;
namespace Library.API.GraphQLSchema
{
    //public class LibrarySchema:Schema
    //{
        //public LibrarySchema(LibraryQuery query,IDependencyResolver dependencyResolver)
        //{
        //    Query = query;

        //    //DependencyResolver.SetResolver ( dependencyResolver);
        //    // = dependencyResolver;
            
        //}
        public class LibrarySchema : GraphQL.Types.Schema
        {
            public LibrarySchema(IDependencyResolver dependencyResolver, LibraryQuery moviesQuery)
            {
                DependencyResolver = dependencyResolver;
                Query = moviesQuery;
            }



        }

    
}
